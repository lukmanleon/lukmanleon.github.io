<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 */
?>
<?php
$footerHideBlog = false;
$footerHidePost = false;
$pagePost = is_single();
$pageBlog = is_home(); ?>
		</div><!-- #content -->
<?php if (!$pageBlog && !$pagePost || $pageBlog && !$footerHideBlog || $pagePost && !$footerHidePost) { ?>
        <footer class="u-align-left u-clearfix u-footer u-grey-80 u-footer" id="sec-0bd1">
  <div class="u-clearfix u-sheet u-sheet-1">
    <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
      <div class="u-layout">
        <div class="u-layout-col">
          <div class="u-size-30">
            <div class="u-layout-row">
              <div class="u-container-style u-layout-cell u-left-cell u-size-20 u-layout-cell-1">
                <div class="u-container-layout u-valign-bottom u-container-layout-1">
                  <span class="u-icon u-icon-circle u-text-white u-icon-1">
                    <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-8a6b"></use></svg>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" id="svg-8a6b" style="enable-background:new 0 0 512 512;"><g><g><path d="M486.279,80.51L256,309.789L25.721,80.51C16.437,84.952,8.952,92.437,4.51,101.721l219.674,218.674    c16.963,16.963,46.685,16.963,63.618,0L507.49,101.719C503.048,92.436,495.563,84.952,486.279,80.51z"></path>
</g>
</g><g><g><polygon points="63.633,76 256,267.367 448.367,76   "></polygon>
</g>
</g><g><g><path d="M0,139.635V391c0,19.53,12.578,36.024,30,42.237V169.635L0,139.635z"></path>
</g>
</g><g><g><path d="M422,229.633L310.027,341.605c-14.135,14.151-33.959,21.944-54.027,21.944s-38.892-7.793-53.042-21.943L90,229.638    l-30-30.002V436c143.19,0,248.741,0,392,0V199.633L422,229.633z"></path>
</g>
</g><g><g><path d="M482,169.633v263.604c17.422-6.213,30-22.707,30-42.237V139.633L482,169.633z"></path>
</g>
</g></svg>
                  </span>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-20 u-layout-cell-2">
                <div class="u-container-layout u-valign-middle u-container-layout-2">
                  <span class="u-icon u-icon-circle u-text-white u-icon-2" data-href="https://www.linkedin.com/in/lukman-leon" data-target="_blank">
                    <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-b569"></use></svg>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 512 512" id="svg-b569"><path d="m437 0h-362c-41.351562 0-75 33.648438-75 75v362c0 41.351562 33.648438 75 75 75h362c41.351562 0 75-33.648438 75-75v-362c0-41.351562-33.648438-75-75-75zm-256 406h-60v-210h60zm0-240h-60v-60h60zm210 240h-60v-120c0-16.539062-13.460938-30-30-30s-30 13.460938-30 30v120h-60v-210h60v11.308594c15.71875-4.886719 25.929688-11.308594 45-11.308594 40.691406.042969 75 36.546875 75 79.6875zm0 0"></path></svg>
                  </span>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-right-cell u-size-20 u-layout-cell-3">
                <div class="u-container-layout u-valign-middle u-container-layout-3">
                  <span class="u-icon u-icon-circle u-text-white u-icon-3" data-href="https://github.com/lukmanleon" data-target="_blank">
                    <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 24 24" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-e24c"></use></svg>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 24 24" id="svg-e24c"><path d="m12 .5c-6.63 0-12 5.28-12 11.792 0 5.211 3.438 9.63 8.205 11.188.6.111.82-.254.82-.567 0-.28-.01-1.022-.015-2.005-3.338.711-4.042-1.582-4.042-1.582-.546-1.361-1.335-1.725-1.335-1.725-1.087-.731.084-.716.084-.716 1.205.082 1.838 1.215 1.838 1.215 1.07 1.803 2.809 1.282 3.495.981.108-.763.417-1.282.76-1.577-2.665-.295-5.466-1.309-5.466-5.827 0-1.287.465-2.339 1.235-3.164-.135-.298-.54-1.497.105-3.121 0 0 1.005-.316 3.3 1.209.96-.262 1.98-.392 3-.398 1.02.006 2.04.136 3 .398 2.28-1.525 3.285-1.209 3.285-1.209.645 1.624.24 2.823.12 3.121.765.825 1.23 1.877 1.23 3.164 0 4.53-2.805 5.527-5.475 5.817.42.354.81 1.077.81 2.182 0 1.578-.015 2.846-.015 3.229 0 .309.21.678.825.56 4.801-1.548 8.236-5.97 8.236-11.173 0-6.512-5.373-11.792-12-11.792z"></path></svg>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="u-size-30">
            <div class="u-layout-row">
              <div class="u-align-center u-container-style u-hidden-sm u-hidden-xs u-layout-cell u-left-cell u-size-20 u-layout-cell-4">
                <div class="u-container-layout u-valign-top u-container-layout-4">
                  <p class="u-text u-text-default u-text-1">lukman.leon@gmail.com</p>
                </div>
              </div>
              <div class="u-align-center u-container-style u-hidden-sm u-hidden-xs u-layout-cell u-size-20 u-layout-cell-5">
                <div class="u-container-layout u-valign-top u-container-layout-5">
                  <p class="u-text u-text-default u-text-2">
                    <a href="https://www.linkedin.com/in/lukman-leon" target="_blank">linkedin.com/in/lukman-leon</a>
                  </p>
                </div>
              </div>
              <div class="u-container-style u-hidden-sm u-hidden-xs u-layout-cell u-right-cell u-size-20 u-layout-cell-6">
                <div class="u-container-layout u-valign-top u-container-layout-6">
                  <p class="u-align-center u-text u-text-default u-text-3">
                    <a href="https://github.com/lukmanleon" target="_blank">github.com/lukmanleon</a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<?php } ?>
        <?php $showBackLink = get_option('np_hide_backlink') ? false : true; ?>
<?php if ($showBackLink) : ?>
<section class="u-backlink u-clearfix u-grey-80">
            <a class="u-link" href="https://nicepage.com/wordpress-themes" target="_blank">
        <span>WordPress Theme</span>
            </a>
        <p class="u-text"><span>created with</span></p>
        <a class="u-link" href="https://nicepage.com/wordpress-themes" target="_blank"><span>Nicepage</span></a>.
    </section>
<?php endif; ?>
        
	</div><!-- .site-inner -->
</div><!-- #page -->

<?php wp_footer(); ?>
<?php back_to_top(); ?>
</body>
</html>
