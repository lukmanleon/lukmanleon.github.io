<!-- index styles -->

<style>.u-section-1 .u-sheet-1 {min-height: 878px}
.u-section-1 .u-image-1 {height: 530px; margin: 60px auto 0 0}
.u-section-1 .u-text-1 {margin: 30px 0 0}
.u-section-1 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-1 .u-text-2 {margin: 40px 0 0}
.u-section-1 .u-link-1 {margin: 30px auto 50px 0} 
@media (max-width: 1199px){ .u-section-1 .u-image-1 {margin-right: initial; margin-left: initial}
.u-section-1 .u-text-1 {margin-right: initial; margin-left: initial}
.u-section-1 .u-metadata-1 {font-weight: 400}
.u-section-1 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 991px){ .u-section-1 .u-sheet-1 {min-height: 888px}
.u-section-1 .u-link-1 {margin-bottom: 60px} }
@media (max-width: 767px){ .u-section-1 .u-sheet-1 {min-height: 735px}
.u-section-1 .u-image-1 {height: 362px; margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-1 .u-sheet-1 {min-height: 700px}
.u-section-1 .u-image-1 {height: 302px; margin-right: initial; margin-left: initial} }
.u-section-2 .u-sheet-1 {min-height: 878px}
.u-section-2 .u-image-1 {height: 530px; margin: 60px auto 0 0}
.u-section-2 .u-text-1 {margin: 30px 0 0}
.u-section-2 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-2 .u-text-2 {margin: 40px 0 0}
.u-section-2 .u-link-1 {margin: 30px auto 50px 0} 
@media (max-width: 1199px){ .u-section-2 .u-image-1 {margin-right: initial; margin-left: initial}
.u-section-2 .u-text-1 {margin-right: initial; margin-left: initial}
.u-section-2 .u-metadata-1 {font-weight: 400}
.u-section-2 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 991px){ .u-section-2 .u-sheet-1 {min-height: 888px}
.u-section-2 .u-link-1 {margin-bottom: 60px} }
@media (max-width: 767px){ .u-section-2 .u-sheet-1 {min-height: 735px}
.u-section-2 .u-image-1 {height: 362px; margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-2 .u-sheet-1 {min-height: 700px}
.u-section-2 .u-image-1 {height: 302px; margin-right: initial; margin-left: initial} }
.u-section-3 .u-sheet-1 {min-height: 878px}
.u-section-3 .u-image-1 {height: 530px; margin: 60px auto 0 0}
.u-section-3 .u-text-1 {margin: 30px 0 0}
.u-section-3 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-3 .u-text-2 {margin: 40px 0 0}
.u-section-3 .u-link-1 {margin: 30px auto 50px 0} 
@media (max-width: 1199px){ .u-section-3 .u-image-1 {margin-right: initial; margin-left: initial}
.u-section-3 .u-text-1 {margin-right: initial; margin-left: initial}
.u-section-3 .u-metadata-1 {font-weight: 400}
.u-section-3 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 991px){ .u-section-3 .u-sheet-1 {min-height: 888px}
.u-section-3 .u-link-1 {margin-bottom: 60px} }
@media (max-width: 767px){ .u-section-3 .u-sheet-1 {min-height: 735px}
.u-section-3 .u-image-1 {height: 362px; margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-3 .u-sheet-1 {min-height: 700px}
.u-section-3 .u-image-1 {height: 302px; margin-right: initial; margin-left: initial} }
.u-section-4 .u-sheet-1 {min-height: 878px}
.u-section-4 .u-image-1 {height: 530px; margin: 60px auto 0 0}
.u-section-4 .u-text-1 {margin: 30px 0 0}
.u-section-4 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-4 .u-text-2 {margin: 40px 0 0}
.u-section-4 .u-link-1 {margin: 30px auto 50px 0} 
@media (max-width: 1199px){ .u-section-4 .u-image-1 {margin-right: initial; margin-left: initial}
.u-section-4 .u-text-1 {margin-right: initial; margin-left: initial}
.u-section-4 .u-metadata-1 {font-weight: 400}
.u-section-4 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 991px){ .u-section-4 .u-sheet-1 {min-height: 888px}
.u-section-4 .u-link-1 {margin-bottom: 60px} }
@media (max-width: 767px){ .u-section-4 .u-sheet-1 {min-height: 735px}
.u-section-4 .u-image-1 {height: 362px; margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-4 .u-sheet-1 {min-height: 700px}
.u-section-4 .u-image-1 {height: 302px; margin-right: initial; margin-left: initial} }
.u-section-5 .u-sheet-1 {min-height: 107px}
.u-section-5 .u-pagination-1 {margin: 25px auto} 
@media (max-width: 1199px){ .u-section-5 .u-pagination-1 {margin-bottom: 0} }
@media (max-width: 575px){ .u-section-5 .u-sheet-1 {min-height: 164px} }
</style>
