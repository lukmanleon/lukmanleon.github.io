<!-- footer styles -->

<style>.u-footer {background-image: none}
.u-footer .u-sheet-1 {min-height: 302px}
.u-footer .u-layout-wrap-1 {margin: 50px 0 0}
.u-footer .u-layout-cell-1 {min-height: 126px}
.u-footer .u-container-layout-1 {padding: 30px}
.u-footer .u-icon-1 {height: 64px; width: 64px; margin: 0 auto}
.u-footer .u-layout-cell-2 {min-height: 126px}
.u-footer .u-container-layout-2 {padding: 30px}
.u-footer .u-icon-2 {height: 64px; width: 64px; margin: 0 auto}
.u-footer .u-layout-cell-3 {min-height: 126px}
.u-footer .u-container-layout-3 {padding: 30px}
.u-footer .u-icon-3 {height: 64px; width: 64px; margin: 0 auto}
.u-footer .u-layout-cell-4 {min-height: 126px}
.u-footer .u-container-layout-4 {padding: 30px}
.u-footer .u-text-1 {font-size: 1.125rem; margin: 0 auto}
.u-footer .u-layout-cell-5 {min-height: 126px}
.u-footer .u-container-layout-5 {padding: 30px}
.u-footer .u-text-2 {font-size: 1.125rem; margin: 0 26px}
.u-footer .u-layout-cell-6 {min-height: 126px}
.u-footer .u-container-layout-6 {padding: 30px}
.u-footer .u-text-3 {font-size: 1.125rem; margin: 0 auto} 
@media (max-width: 1199px){ .u-footer .u-sheet-1 {min-height: 29px}
.u-footer .u-layout-wrap-1 {margin-right: initial; margin-left: initial}
.u-footer .u-layout-cell-1 {min-height: 104px}
.u-footer .u-layout-cell-2 {min-height: 104px}
.u-footer .u-layout-cell-3 {min-height: 104px}
.u-footer .u-layout-cell-4 {min-height: 104px}
.u-footer .u-layout-cell-5 {min-height: 104px}
.u-footer .u-text-2 {margin-left: 20px; margin-right: 20px}
.u-footer .u-layout-cell-6 {min-height: 104px} }
@media (max-width: 991px){ .u-footer .u-layout-cell-1 {min-height: 80px}
.u-footer .u-layout-cell-2 {min-height: 80px}
.u-footer .u-layout-cell-3 {min-height: 80px}
.u-footer .u-layout-cell-4 {min-height: 80px}
.u-footer .u-text-1 {font-size: 0.875rem}
.u-footer .u-layout-cell-5 {min-height: 80px}
.u-footer .u-text-2 {font-size: 0.875rem; margin-left: 14px; margin-right: 14px}
.u-footer .u-layout-cell-6 {min-height: 80px}
.u-footer .u-text-3 {font-size: 0.875rem} }
@media (max-width: 767px){ .u-footer .u-sheet-1 {min-height: 387px}
.u-footer .u-layout-cell-1 {min-height: 100px}
.u-footer .u-container-layout-1 {padding-left: 10px; padding-right: 10px}
.u-footer .u-layout-cell-2 {min-height: 100px}
.u-footer .u-container-layout-2 {padding-left: 10px; padding-right: 10px}
.u-footer .u-layout-cell-3 {min-height: 100px}
.u-footer .u-container-layout-3 {padding-left: 10px; padding-right: 10px}
.u-footer .u-layout-cell-4 {min-height: 100px}
.u-footer .u-container-layout-4 {padding-left: 10px; padding-right: 10px}
.u-footer .u-layout-cell-5 {min-height: 100px}
.u-footer .u-container-layout-5 {padding-left: 10px; padding-right: 10px}
.u-footer .u-text-2 {margin-left: auto; margin-right: auto}
.u-footer .u-layout-cell-6 {min-height: 100px}
.u-footer .u-container-layout-6 {padding-left: 10px; padding-right: 10px} }
@media (max-width: 575px){ .u-footer .u-sheet-1 {min-height: 282px} }</style>
