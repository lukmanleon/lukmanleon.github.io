<!-- post styles -->

<style>.u-section-1 {background-image: none}
.u-section-1 .u-sheet-1 {min-height: 783px}
.u-section-1 .u-image-1 {height: 500px; margin: 60px auto 0 0}
.u-section-1 .u-text-1 {margin: 30px 0 0}
.u-section-1 .u-metadata-1 {margin: 13px auto 0 0}
.u-section-1 .u-text-2 {margin: 30px 0 -14px} 
@media (max-width: 1199px){ .u-section-1 .u-image-1 {margin-right: initial; margin-left: initial}
.u-section-1 .u-text-1 {margin-right: initial; margin-left: initial} }
@media (max-width: 991px){ .u-section-1 .u-sheet-1 {min-height: 768px}
.u-section-1 .u-image-1 {height: 460px; margin-right: initial; margin-left: initial} }
@media (max-width: 767px){ .u-section-1 .u-text-2 {margin-right: initial; margin-left: initial} }
@media (max-width: 575px){ .u-section-1 .u-sheet-1 {min-height: 659px}
.u-section-1 .u-image-1 {height: 326px; margin-right: initial; margin-left: initial} }
</style>
