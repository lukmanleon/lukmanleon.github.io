<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {background-image: none}
.u-header .u-sheet-1 {min-height: 51px}
.u-header .u-shape-1 {height: 50px; width: 1420px; background-image: none; margin: -2px auto 0 -149px}
.u-header .u-menu-1 {margin: -45px auto 8px 0}
.u-header .u-nav-1 {font-size: 1.25rem; font-weight: 700}
.u-header .u-nav-2 {box-shadow: 2px 2px 8px 0 rgba(128,128,128,1); font-size: 1rem}
.u-header .u-sidenav-1 {width: 514px; margin-right: 0; margin-left: 0}
.u-header .u-nav-3 {font-size: 1.25rem}
.u-header .u-nav-4 {box-shadow: 2px 2px 8px 0 rgba(128,128,128,1); font-size: 1rem} 
@media (max-width: 1199px){ .u-header .u-sheet-1 {min-height: 51px}
.u-header .u-shape-1 {width: 1040px; margin-left: -50px; margin-right: -50px} }
@media (max-width: 991px){ .u-header .u-shape-1 {width: 820px} }
@media (max-width: 767px){ .u-header .u-sheet-1 {min-height: 71px}
.u-header .u-shape-1 {height: 60px; width: 640px; margin-top: 6px}
.u-header .u-menu-1 {width: auto; margin-top: -50px; margin-bottom: 15px; margin-left: 30px} }
@media (max-width: 575px){ .u-header .u-sheet-1 {min-height: 144px}
.u-header .u-shape-1 {margin-top: 20px; width: 340px; margin-left: 0; margin-right: 0}
.u-header .u-menu-1 {margin-top: -52px; margin-bottom: 60px; margin-left: 20px} }</style>
